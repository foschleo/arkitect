// This file can be used for drawing helper functions if needed in the future.
// For now, it's a valid empty module to prevent parsing issues.

export {};
